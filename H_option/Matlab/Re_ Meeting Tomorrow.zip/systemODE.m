function dState = systemODE(t, state)
k1 = 0.05;
k2 = 0.2;
A0 = 2.0;
B0 = 1.5;
C0 = 3.0;
D0=0;
B = state(1);
I = state(2);
D = state(3);
dBdt = -k1 * B * (A0 - B0 + B);
dIdt = k1 * ((A0 - B0) + B) * B - k2 * I * (C0 - (D - D0));
dDdt = k2 * I * (C0 - (D - D0));
dState = [dBdt; dIdt; dDdt];
end